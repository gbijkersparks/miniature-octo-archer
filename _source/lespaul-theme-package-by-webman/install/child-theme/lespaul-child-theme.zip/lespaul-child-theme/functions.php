<?php
/*
*****************************************************
* Created by WebMan - www.webmandesign.eu
*
* All of !LesPaul functions are pluggable,
* which means you can redefine them in this file
* and these redefined functions will then be used
* in this child theme.
*****************************************************
*/